import psycopg

conn = psycopg.connect("dbname=esports user=usuario password=contraseña host=localhost")
cursor = conn.cursor()

def crear_tablas():
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS equipos (
            id SERIAL PRIMARY KEY,
            nombre TEXT NOT NULL UNIQUE,
            pais TEXT,
            entrenador TEXT
        );
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS jugadores (
            id SERIAL PRIMARY KEY,
            nickname TEXT NOT NULL UNIQUE,
            rol TEXT NOT NULL,
            equipo_id INTEGER REFERENCES equipos(id) ON DELETE CASCADE
        );
    ''')
    conn.commit()

def insertar_equipo(nombre, pais, entrenador):
    cursor.execute('INSERT INTO equipos (nombre, pais, entrenador) VALUES (%s, %s, %s)', (nombre, pais, entrenador))
    conn.commit()

def insertar_jugador(nickname, rol, equipo_id):
    cursor.execute('INSERT INTO jugadores (nickname, rol, equipo_id) VALUES (%s, %s, %s)', (nickname, rol, equipo_id))
    conn.commit()

def leer_datos():
    cursor.execute('SELECT * FROM equipos')
    equipos = cursor.fetchall()
    for equipo in equipos:
        print(f"Equipo: {equipo[1]}, País: {equipo[2]}, Entrenador: {equipo[3]}")
        cursor.execute('SELECT nickname, rol FROM jugadores WHERE equipo_id = %s', (equipo[0],))
        jugadores = cursor.fetchall()
        for jugador in jugadores:
            print(f"  - Jugador: {jugador[0]}, Rol: {jugador[1]}")

def actualizar_equipo(id_equipo, nuevo_nombre):
    cursor.execute('UPDATE equipos SET nombre = %s WHERE id = %s', (nuevo_nombre, id_equipo))
    conn.commit()

def actualizar_jugador(id_jugador, nuevo_nickname):
    cursor.execute('UPDATE jugadores SET nickname = %s WHERE id = %s', (nuevo_nickname, id_jugador))
    conn.commit()

def eliminar_equipo(id_equipo):
    cursor.execute('DELETE FROM equipos WHERE id = %s', (id_equipo,))
    conn.commit()

def eliminar_jugador(id_jugador):
    cursor.execute('DELETE FROM jugadores WHERE id = %s', (id_jugador,))
    conn.commit()

def cerrar_conexion():
    cursor.close()
    conn.close()

if __name__ == "__main__":
    crear_tablas()
    insertar_equipo("Team A", "España", "Coach X")
    insertar_jugador("Player1", "Support", 1)
    leer_datos()
    actualizar_equipo(1, "Team Alpha")
    eliminar_jugador(1)
    eliminar_equipo(1)
    cerrar_conexion()
